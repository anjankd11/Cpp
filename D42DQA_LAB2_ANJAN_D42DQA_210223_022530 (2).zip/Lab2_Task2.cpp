/*Task 2. Modify the given program so that the array size is not fixed anymore.Ask a user for the
actual array size before reading the array elements.Consider dynamic memory management
(recall it from C).*/

#define _CRT_SECURE_NO_WARNINGS 
#include <stdio.h>
#include <stdlib.h>

//#define ARRAY_MAX 5[commented this part because we don't need the pre determined value anymore]

int compare(const void* a, const void* b)
{
	// Returning value: <0, if a<b;
	// 0, if a=b;
	 // >0, if a>b.

	double* da = (double*)a, * db = (double*)b;
	if (*da < *db)return-1;
	else if (*da == *db) return 0;
	else return 1;
}
int main()
{   
	
	int n;

	printf("How many number you want to input?");
	scanf_s("%d", &n);//taking user input to determine the size of the array

	double* d=(double*)malloc(sizeof(double)*n);//allocating memmory dynamically to store numbers
	

	int i;

	for (i = 0; i < n; i++)
		{
			printf("Enter number no. %d:", i+1);//edited to show which number is being input
			scanf_s("%lf", &d[i]);
		}

	qsort(d, n, sizeof(double), compare);

	for (i = 0; i < n; i++)
		{
			printf("%lf ", d[i]);
		}

		free(d);
	
	return 0;
}
